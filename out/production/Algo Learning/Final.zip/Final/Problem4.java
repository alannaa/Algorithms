package Final;


import Final.Problem4.TernarySearchTrie.NodeWithSize;

public class Problem4 {

  //5.2.10 Size. Implement very eager size() (that keeps in each node the
  // number of keys in its subtree) for TrieST and TST.

  public static class TrieST<Value> extends Trie<Value> {

    private NodeWithSize root = new NodeWithSize();

    //NodeWithSize is a variation of Node that eagerly stores the size when
    //its calculated
    private static class NodeWithSize extends Node {
      private int size;
      private NodeWithSize[] next = new NodeWithSize[(int) "z".charAt(0)];
    }


    //this is the size() method the problem statement asks us to implement
    // eagerly. returns the size stored at the root.
    public int size() {
      if (root != null) {
        return root.size;
      }
      return 0;
    }

    private int size(NodeWithSize nodeWithSize) {
      if (nodeWithSize != null) {
        return nodeWithSize.size;
      }
      return 0;
    }

    public boolean contains(String key) {
      if (key == null) {
        throw new IllegalArgumentException("Key cannot be found");
      }
      return get(key) != null;
    }

    @Override
    public Value get(String key) {
      if (key == null) {
        throw new IllegalArgumentException("Key cannot be found");
      }

      if (key.length() == 0) {
        throw new IllegalArgumentException("Key must have a positive length");
      }

      Node node = get(root, key, 0);

      if (node == null) {
        return null;
      }
      return (Value) node.value;
    }

    private Node get(NodeWithSize node, String key, int digit) {
      if (node == null || node.size==0) {
        return null;
      }

      if (digit == key.length()) {
        return node;
      }

      char nextChar = key
          .charAt(digit); // Use digitTh key char to identify subtrie.
      return get(node.next[nextChar], key, digit + 1);
    }

    @Override
    public void put(String key, Value value) {
      if (key == null) {
        throw new IllegalArgumentException("Key cannot be null");
      }

      boolean isNewKey = false;

      if (!contains(key)) {
        isNewKey = true;
      }

      if (value == null) {
        delete(key);
      } else {
        root = put(root, key, value, 0, isNewKey);
      }
    }

    private NodeWithSize put(NodeWithSize node, String key, Value value,
        int digit, boolean isNewKey) {
      if (node == null) {
        node = new NodeWithSize();
      }

      //this line is precisely where the very eager implementation takes place
      // as soon as a new key is put into the trie, the root's size
      // increments by 1
      if (isNewKey) {
        node.size = node.size + 1;
      }

      //in this case, node is a NodeWithSize object, but because that class
      // extends the regular node, we have a 'value' field.
      if (digit == key.length()) {
        node.value = value;
        return node;
      }

      //finally, populate the next field
      char nextChar = key.charAt(digit); //Use digitTh key char to identify subtrie.

    

      node.next[nextChar] = put(node.next[nextChar], key, value, digit + 1,
          isNewKey);

      return node;
    }

    @Override
    public void delete(String key) {
      if (key == null) {
        throw new IllegalArgumentException("Key cannot be null");
      }

      if (!contains(key)) {
        return;
      }

      root = delete(root, key, 0);
    }

    private NodeWithSize delete(NodeWithSize node, String key, int digit) {
      if (node == null) {
        return null;
      }

      node.size = node.size - 1;

      if (digit == key.length()) {
        node.value = null;
      } else {
        char nextChar = key.charAt(digit);
        node.next[nextChar] = delete(node.next[nextChar], key, digit + 1);
      }

      if (node.value != null) {
        return node;
      }

      for (char nextChar = 0; nextChar < node.size; nextChar++) {
        if (node.next[nextChar] != null) {
          return node;
        }
      }

      return null;
    }
  }


  ////////////////////////////////////////////////////////////////////


  public static class TernarySearchTrie<Value> {

    private int size;
    private NodeWithSize root;


    class Node {
      char character;
      Value value;
      int size;

      Node left;
      Node middle;
      Node right;
    }

    class NodeWithSize extends Node {
      private int size;
      private NodeWithSize left;
      private NodeWithSize middle;
      private NodeWithSize right;
    }

    public int size() {
      return size;
    }

    public boolean contains(String key) {
      if (key == null) {
        throw new IllegalArgumentException("Key cannot be null");
      }

      return get(key) != null;
    }


    public Value get(String key) {
      if (key == null) {
        throw new IllegalArgumentException("Key cannot be null");
      }

      if (key.length() == 0) {
        throw new IllegalArgumentException("Key must have a positive length");
      }

      NodeWithSize node = get(root, key, 0);

      if (node == null) {
        return null;
      }
      return (Value) node.value;
    }

    private NodeWithSize get(NodeWithSize node, String key, int digit) {
      if (node == null) {
        return null;
      }

      char currentChar = key.charAt(digit);

      if (currentChar < node.character) {
        return get(node.left, key, digit);
      } else if (currentChar > node.character) {
        return get(node.right, key, digit);
      } else if (digit < key.length() - 1) {
        return get(node.middle, key, digit + 1);
      } else {
        return node;
      }
    }

    public void put(String key, Value value) {
      if (key == null) {
        throw new IllegalArgumentException("Key cannot be null");
      }

      if (value == null) {
        delete(key);
        return;
      }

      boolean isNewKey = false;

      if (!contains(key)) {
        isNewKey = true;
        size++;
      }

      root = put(root, key, value, 0, isNewKey);
    }

    private NodeWithSize put(NodeWithSize node, String key, Value value, int digit, boolean isNewKey) {
      char currentChar = key.charAt(digit);

      if (node == null) {
        node = new NodeWithSize();
        node.character = currentChar;
      }

      if (currentChar < node.character) {
        node.left = put(node.left, key, value, digit, isNewKey);
      } else if (currentChar > node.character) {
        node.right = put(node.right, key, value, digit, isNewKey);
      } else if (digit < key.length() - 1) {
        node.middle = put(node.middle, key, value, digit + 1, isNewKey);

        if (isNewKey) {
          node.size = node.size + 1;
        }
      } else {
        node.value = value;

        if (isNewKey) {
          node.size = node.size + 1;
        }
      }

      return node;
    }

    public void delete(String key) {
      if (key == null) {
        throw new IllegalArgumentException("Key cannot be null");
      }

      if (!contains(key)) {
        return;
      }

      root = delete(root, key, 0);
      size--;
    }

    private NodeWithSize delete(NodeWithSize node, String key, int digit) {
      if (node == null) {
        return null;
      }

      if (digit == key.length() - 1) {
        node.size = node.size - 1;
        node.value = null;
      } else {
        char nextChar = key.charAt(digit);

        if (nextChar < node.character) {
          node.left = delete(node.left, key, digit);
        } else if (nextChar > node.character) {
          node.right = delete(node.right, key, digit);
        } else {
          node.size = node.size - 1;
          node.middle = delete(node.middle, key, digit + 1);
        }
      }

      if (node.size == 0) {
        if (node.left == null && node.right == null) {
          return null;
        } else if (node.left == null) {
          return node.right;
        } else if (node.right == null) {
          return node.left;
        } else {
          NodeWithSize aux = node;
          node = min(aux.right);
          node.right = deleteMin(aux.right);
          node.left = aux.left;
        }
      }

      return node;
    }

    private NodeWithSize min(NodeWithSize node) {
      if (node.left == null) {
        return node;
      }

      return min(node.left);
    }

    private NodeWithSize deleteMin(NodeWithSize node) {
      if (node.left == null) {
        return node.right;
      }

      node.left = deleteMin(node.left);
      return node;
    }
  }

  public static void main(String[] args) {
    Problem4 p4 = new Problem4();

    TrieST trieST = new TrieST();
    System.out.println("new trieST size: " + trieST.size());

    trieST.put("test", 0);


  }



}
